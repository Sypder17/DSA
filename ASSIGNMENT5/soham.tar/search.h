
int linearS(int arr[],int n,int key);
int BinaryS(int arr[],int n,int key);
